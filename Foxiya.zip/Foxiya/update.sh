cd Reverse
tree -H '1' -L 1 --noreport --charset utf-8 > index.html
cd ..
cd Hacking
tree -H '1' -L 1 --noreport --charset utf-8 > index.html
cd ..
cd Linux
tree -H '1' -L 1 --noreport --charset utf-8 > index.html
