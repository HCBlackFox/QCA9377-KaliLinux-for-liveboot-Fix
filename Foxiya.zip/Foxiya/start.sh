lt --port 80 --subdomain foxiya | sudo python3 -m http.server 80
