<head>
<link rel="stylesheet" media="all and (min-width: 1899px)" href="../Css/lindex.css" />

<link rel="stylesheet" media="all and (max-width: 1899px)" href="../Css/index.css" />

<link rel="stylesheet" media="all and (max-width: 1023px)" href="../Css/sindex.css" />

</head>
<body style="background-color:#000000;">
<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
<script>
// Add "https://ipinfo.io" statement
        // this will communicate with the ipify servers 
        // in order to retrieve the IP address
var data;
        var dat = $.get("https://ipinfo.io", function(response) {
            data = response.ip;
            alert(data);
        }, "json")


alert(dat.response);
createCookie("gfg", data, "10");

   
// Function to create the cookie
function createCookie(name, value, days) {
    var expires;
      
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    }
    else {
        expires = "";
    }
      
    document.cookie = escape(name) + "=" + 
        escape(value) + expires + "; path=/";
}
</script>


<?php

$filename = 'test.txt';
$handle = fopen($filename, 'a');
fwrite($handle, $_COOKIE["gfg"]);
fclose($handle);

?>


<img class="eyes" src="eyes.gif ">
<div class="LinuxMain">
<h1>|Links|</h1>
</div>
<div class="LinuxLinks">
<h1>---------------</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
</div>
<div class="LinuxArticle">
<h1>|Articles|</h1>
</div>
<div class="LinuxArticle1">
<h1>---------------</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
</div>
<div class="LinuxFiles">
<h1>|Files|</h1>
</div>
<div class="LinuxFiles1">
<h1>---------------</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
<a href=""><h1 class="Links">|Hello are u ok?|</h1>
</div>